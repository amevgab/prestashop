<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pleasewait}prestashop>pleasewait_0b171b59d90e2a5595bae5ae075d8bd1'] = 'Warten Sie mal...!';
$_MODULE['<{pleasewait}prestashop>pleasewait_6e5a2ae4d41d81d1439888aafed7faf5'] = 'Zeigen Sie beim Laden Ihrer Website ein Ladesymbol an';
$_MODULE['<{pleasewait}prestashop>pleasewait_92328ef0a137839f00cf029c11501175'] = 'Laden-Symbol aktivieren';
$_MODULE['<{pleasewait}prestashop>pleasewait_6d6c669b98589d5cd2abea03d3cea936'] = 'Wird geladen';
$_MODULE['<{pleasewait}prestashop>pleasewait_fc23ffe3bc715a46cc8b63071ded5fda'] = 'Größe des Symbols';
$_MODULE['<{pleasewait}prestashop>pleasewait_4c2a8fe7eaf24721cc7a9f0175115bd4'] = 'Nachricht';
$_MODULE['<{pleasewait}prestashop>pleasewait_fa69ac6795d55bd7a44fe47ae4a7a854'] = 'Anzeige nur auf Homepage';
$_MODULE['<{pleasewait}prestashop>pleasewait_534b7c706186028f1b4f51344bbca176'] = 'Symbolfarbe';
$_MODULE['<{pleasewait}prestashop>pleasewait_5f111ae4c490902059da2004cbc8b424'] = 'Textfarbe';
$_MODULE['<{pleasewait}prestashop>pleasewait_368d9ac76af05f714092bc808a426bfc'] = 'Hintergrundfarbe';
$_MODULE['<{pleasewait}prestashop>pleasewait_96fd2b796454b8598b7029086421930c'] = 'Hintergrund-Deckkraft';
$_MODULE['<{pleasewait}prestashop>pleasewait_25e56d2ad1d3e904ef3e481e6fca76e1'] = 'Hintergrund-Opazität ist eine Float-Zahl von 0 bis 1';
$_MODULE['<{pleasewait}prestashop>pleasewait_254f642527b45bc260048e30704edb39'] = 'Konfiguration';
$_MODULE['<{pleasewait}prestashop>pleasewait_c9cc8cce247e49bae79f15173ce97354'] = 'sparen';
$_MODULE['<{pleasewait}prestashop>pleasewait_93cba07454f06a4a960172bbd6e2a435'] = 'ja';
$_MODULE['<{pleasewait}prestashop>pleasewait_bafd7322c6e97d25b6299b5d6fe8920b'] = 'Nein';
$_MODULE['<{pleasewait}prestashop>pleasewait_a2dfd34e4a55c47d43aedebb87a7ed58'] = 'Kann nicht größer als 100Mb sein';
$_MODULE['<{pleasewait}prestashop>pleasewait_ebba06a4de65f4f86cb2cac1341df1e2'] = 'Die Symbolgröße ist ungültig';
$_MODULE['<{pleasewait}prestashop>pleasewait_d0911abf98053fbc867f130b0133b92b'] = 'Die Symbolfarbe ist ungültig';
$_MODULE['<{pleasewait}prestashop>pleasewait_7cc92687130ea12abb80556681538001'] = 'Während des Image-Upload-Vorgangs ist ein Fehler aufgetreten.';
$_MODULE['<{pleasewait}prestashop>form_9f5eba7179014f3c071cba0c406523fc'] = 'Alle Lade-Symbol-Typen anzeigen';
